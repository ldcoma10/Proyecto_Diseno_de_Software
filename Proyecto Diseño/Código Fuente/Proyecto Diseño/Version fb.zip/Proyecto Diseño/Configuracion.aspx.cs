﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Proyecto_Diseño
{
    public partial class Configuracion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [ScriptMethod, WebMethod]
        public static void RenovarContrasena(String usuario, String contrasenaVieja, String contrasenaNueva)
        {

            GestordeUsuario GU = new GestordeUsuario();

            bool registro = GU.RenovarContraseña(usuario, contrasenaVieja,contrasenaNueva);
            if (!registro)
            {
                HttpContext.Current.Response.Redirect("error.aspx", false);
            }


        }
    }
}