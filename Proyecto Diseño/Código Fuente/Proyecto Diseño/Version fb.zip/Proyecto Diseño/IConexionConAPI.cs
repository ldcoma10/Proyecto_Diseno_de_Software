﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Proyecto_Diseño
{
    // File:    IConexionConAPI.cs
    // Author:  Erick,Luis
    // Created: jueves 22 de mayo de 2014 01:32:37 a.m.
    // Purpose: Definition of Interface IConexionConAPI

    using System;

    public interface IConexionConAPI
    {
        Object ObtenerConexion();

        int ObtenerEstadoDeConexion();

        int CerrarConexion();

        int EnviarPeticion();

        int ObtenerHileraDeConexion();

    }
}