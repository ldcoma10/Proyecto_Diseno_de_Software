﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Proyecto_Diseño
{
    public partial class VisualizadorDeFoto : System.Web.UI.Page
    {
        System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
        DataTable dt = new DataTable();
        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
                

                    HttpCookie solicitarCookie;
                    solicitarCookie = Request.Cookies["TouristApp"];

                    try
                    {
                        if (solicitarCookie == null)
                        {
                            solicitarCookie.GetType();
                        }
                        else{
                            extraerFotos();
                        }


                    }

                    catch (Exception)
                    {
                        Response.Redirect("Principal.aspx", false);

                    }
                }
            
        
        }

        protected void extraerFotos()
        {
            try
            {
                //Tomar el nombre de usuario
                HttpCookie solicitarCookie;
                solicitarCookie = Request.Cookies["TouristApp"];
                string usuario = solicitarCookie.Value.Substring(2);

                ConexionEspecificaABasedeDatos conexion = new ConexionEspecificaABasedeDatos();
                System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection();
                connection.ConnectionString = conexion.getHileradeConexion();
                SqlCommand command = new SqlCommand("SELECT  Comentario,IdFoto from [Foto] where Usuario='" + usuario + "' Order by IdFoto Desc", connection);
                SqlDataAdapter ada = new SqlDataAdapter(command);
                ada.Fill(dt);
                gridImagenes.DataSource = dt;
                gridImagenes.DataBind();

            }
            catch { }
   





        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


    }
}