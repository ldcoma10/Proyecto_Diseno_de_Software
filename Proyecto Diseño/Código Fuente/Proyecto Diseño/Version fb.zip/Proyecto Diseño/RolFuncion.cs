﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Proyecto_Diseño
{
    // File:    RolFuncion.cs
    // Author:  Erick, Luis
    // Created: jueves 22 de mayo de 2014 12:02:53 a.m.
    // Purpose: Definition of Class RolFuncion

    public abstract class RolFuncion
    {
        public String ObtenerNombreFuncion()
        {
            throw new NotImplementedException();
        }

    }
}