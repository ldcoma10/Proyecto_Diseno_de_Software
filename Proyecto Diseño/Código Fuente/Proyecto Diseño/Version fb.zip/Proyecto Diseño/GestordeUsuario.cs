﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Proyecto_Diseño
{
    public class GestordeUsuario
    {
        private int CantidaddeUsuariosConectados;

        public Boolean RegistrarNuevoUsuario(String Correo,String Contraseña) {
            ConexionEspecificaABasedeDatos conexion = new ConexionEspecificaABasedeDatos();

            System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
            con.ConnectionString = conexion.getHileradeConexion();
            SqlCommand cmd = new SqlCommand();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandText = "SELECT email FROM usuario";
                SqlDataReader reader = cmd.ExecuteReader();
                
                bool bandera = false;
                while (reader.Read())
                {

                    if (reader.GetString(0) == Correo)
                    {
                        bandera = true;
                        break;
                    }

                }
                con.Close();
                if(!bandera){

                    cmd = new SqlCommand("INSERT INTO Usuario (EMAIL,Contrasena,Rol) " +
                    "VALUES(@Email,@Contrasena,@Rol)", con);
                cmd.Parameters.Add("@Email", System.Data.SqlDbType.NVarChar,500).Value = Correo;
                cmd.Parameters.Add("@Contrasena", System.Data.SqlDbType.NVarChar,100).Value = Contraseña;
                cmd.Parameters.Add("@Rol", System.Data.SqlDbType.Char, 1).Value = "E";

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                return true;                 
                }
                return false;


            }
            catch (Exception)
            {
                return false;
            }
            
            }
        public Boolean RecuperarContrasena(String Correo) { return false; }
        public Boolean RenovarContraseña(String Correo, String ContrasenaVieja, String ContrasenaNueva)
        {
            ConexionEspecificaABasedeDatos conexion = new ConexionEspecificaABasedeDatos();

            System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
            con.ConnectionString = conexion.getHileradeConexion();
            SqlCommand cmd = new SqlCommand();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandText = "SELECT email,contrasena FROM usuario";
                SqlDataReader reader = cmd.ExecuteReader();

                bool bandera = false;
                while (reader.Read())
                {

                    if (reader.GetString(0) == Correo && reader.GetString(1) == ContrasenaVieja)
                    {
                        bandera = true;
                        break;
                    }

                }
                con.Close();
                if (bandera)
                {

                    cmd = new SqlCommand("Update Usuario set Contrasena= '" + ContrasenaNueva + "' Where email='"+Correo+"'", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    return true;
                }
                return false;


            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool AutenticarUsuario(String Correo,String Contrasena){
            
            ConexionEspecificaABasedeDatos conexion=new ConexionEspecificaABasedeDatos();
           
            System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
            con.ConnectionString = conexion.getHileradeConexion();
            SqlCommand cmd = new SqlCommand(); 
           try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandText = "SELECT email,contrasena FROM usuario";
                SqlDataReader reader = cmd.ExecuteReader();
                bool usuarioRegistrado = false;
                while (reader.Read())
                {
                    String emailprovisional=reader.GetString(0);
                    if (Contrasena != null)
                    {
                        if (emailprovisional == Correo && reader.GetString(1) == Contrasena)
                        {
                            String nombre = reader.GetString(0);
                            String contrasena = reader.GetString(1);
                            usuarioRegistrado = true;
                            break;
                        }
                    }
                    //en caso de iniciar mediante facebook, ya que no se tiene la contraseña
                    else if (Contrasena == null) {
                        if (emailprovisional == Correo)
                        {
                            String nombre = reader.GetString(0);                            
                            usuarioRegistrado = true;
                            break;
                        }
                    }
                    
                    
                }
                
                return usuarioRegistrado;
               
                
            }
            catch (Exception) {
                return false;
            }
            
        }

        public bool EsAdministrador(String Correo) {
            ConexionEspecificaABasedeDatos conexion = new ConexionEspecificaABasedeDatos();

            System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection();
            con.ConnectionString = conexion.getHileradeConexion();
            SqlCommand cmd = new SqlCommand();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandText = "SELECT email,rol FROM usuario";
                SqlDataReader reader = cmd.ExecuteReader();
                
                while (reader.Read())
                {

                    if (reader.GetString(0) == Correo && reader.GetString(1).ToLower()=="a")
                    {
                        return true;
                    }
                    else if (reader.GetString(0) == Correo) {
                        return false;
                    }

                }
                return false;

            }
            catch (Exception)
            {
                return false;
            }
        }


    }
}