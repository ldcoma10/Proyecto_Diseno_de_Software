﻿using System;

namespace Proyecto_Diseño
{
    public class ConexionEspecificaABasedeDatos
    {
       private string NombredeSABD;
       private string HileradeConexion;

       public ConexionEspecificaABasedeDatos() {
           NombredeSABD="Sql Server 2012";           
           HileradeConexion="Data Source=LDiego-PC;Initial Catalog=BaseTouristApp;Integrated Security=True";
           
       }
        public String getHileradeConexion(){
            return HileradeConexion;

        }

    }
    
}