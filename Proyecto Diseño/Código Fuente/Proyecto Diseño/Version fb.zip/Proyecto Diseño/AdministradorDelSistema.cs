﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Proyecto_Diseño
{
    // File:    AdministradorDelSistema.cs
    // Author:  Erick, Luis
    // Created: jueves 22 de mayo de 2014 12:20:51 a.m.
    // Purpose: Definition of Class AdministradorDelSistema

    using System;

    public class AdministradorDelSistema : RolFuncion
    {
        private int codigoDeAdministrador;

        public int CrearAdministradorDeSistema()
        {
            throw new NotImplementedException();
        }

        public int CrearEncargadodeMantenimientoWeb()
        {
            throw new NotImplementedException();
        }

        public int CrearEncargadodeBaseDeDatos()
        {
            throw new NotImplementedException();
        }

    }
}