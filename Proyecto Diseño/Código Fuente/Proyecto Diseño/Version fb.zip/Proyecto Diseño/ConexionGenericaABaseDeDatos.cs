﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Proyecto_Diseño
{
    // File:    ConexionGenericaABaseDeDatos.cs
    // Author:  Erick,Luis
    // Created: jueves 22 de mayo de 2014 03:33:29 a.m.
    // Purpose: Definition of Class ConexionGenericaABaseDeDatos

    using System;

    public class ConexionGenericaABaseDeDatos : IConexionSoloLectura
    {
        private int maximoDeTranferenciaDeDatosPorCadaRequest;
        private int maximoDeConexionesSimultaneasPorUsuario;

        public int ObtenerMaximoDeTransferenciaDeDatosPorRequest()
        {
            throw new NotImplementedException();
        }

        public int ObtenerMaximodeConexionesSimultaneasPorUsuario()
        {
            throw new NotImplementedException();
        }
    }
}