﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Proyecto_Diseño
{
    // File:    ConexionConGoogleMaps.cs
    // Author:  Erick,Luis
    // Created: jueves 22 de mayo de 2014 01:46:23 a.m.
    // Purpose: Definition of Class ConexionConGoogleMaps


    public class ConexionConGoogleMaps : IConexionConAPI
    {
        private ConexionConGoogleMaps conexionConMaps;

        public void UbicarUsuario()
        {
            throw new NotImplementedException();
        }

        public void TrazarRuta(String salida, String llegada)
        {
            throw new NotImplementedException();
        }

        public Object ObtenerConexion()
        {
            throw new NotImplementedException();
        }

        public int ObtenerEstadoDeConexion()
        {
            throw new NotImplementedException();
        }

        public int CerrarConexion()
        {
            throw new NotImplementedException();
        }

        public int EnviarPeticion()
        {
            throw new NotImplementedException();
        }

        public int ObtenerHileraDeConexion()
        {
            throw new NotImplementedException();
        }

    }
}