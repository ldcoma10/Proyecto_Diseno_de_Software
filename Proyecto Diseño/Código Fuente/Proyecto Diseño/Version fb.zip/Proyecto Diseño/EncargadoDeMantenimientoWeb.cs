﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Proyecto_Diseño
{
    // File:    EncargadoDeMantenimientoWeb.cs
    // Author:  Erick,Luis
    // Created: jueves 22 de mayo de 2014 12:30:07 a.m.
    // Purpose: Definition of Class EncargadoDeMantenimientoWeb

    using System;

    public class EncargadoDeMantenimientoWeb : RolFuncion
    {
        private int codigoDeFuncionario;

        public Object ActualizarConexionConAPI(ConexionConGoogleCustomSearch conexion)
        {
            throw new NotImplementedException();
        }

        public Object ActualizarConexionConAPI(ConexionConGoogleMaps conexion)
        {
            throw new NotImplementedException();
        }

        public ConexionConGoogleMaps conexionConGoogleMaps;
        public ConexionConGoogleCustomSearch conexionConGoogleCustomSearch;

    }
}