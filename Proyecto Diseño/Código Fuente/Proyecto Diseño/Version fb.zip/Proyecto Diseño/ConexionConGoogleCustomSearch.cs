﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Proyecto_Diseño
{
    // File:    ConexionConGoogleCustomSearch.cs
    // Author:  Erick,Luis
    // Created: jueves 22 de mayo de 2014 01:46:26 a.m.
    // Purpose: Definition of Class ConexionConGoogleCustomSearch

    using System;

    public class ConexionConGoogleCustomSearch : IConexionConAPI
    {
        private ConexionConGoogleCustomSearch conexionConSearch;

        public void BuscarImagenes(String destino)
        {
            throw new NotImplementedException();
        }

        public Object ObtenerConexion()    {
            throw new NotImplementedException();
        }

        public int ObtenerEstadoDeConexion()    {
            throw new NotImplementedException();
        }

        public int CerrarConexion()    {
            throw new NotImplementedException();
        }

        public int EnviarPeticion()    {
            throw new NotImplementedException();
        }

        public int ObtenerHileraDeConexion()    {
            throw new NotImplementedException();
        }
    }
}