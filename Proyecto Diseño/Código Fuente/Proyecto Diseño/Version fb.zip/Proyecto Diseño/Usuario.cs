﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Proyecto_Diseño
{
    public class Usuario
    {
        private String Correo_electronico;
        private String Contrasena;

        public Usuario(String Correo_electronico,String Contrasena) {
            this.Correo_electronico = Correo_electronico;
            this.Contrasena = Contrasena;
            }

        public String ObtenerCorreo() {
            return Correo_electronico;
        }
        public String modificarCorreo() { return ""; }
        private String ObtenerContrasena() { return Contrasena; }
        public void modificarContrasena(String NuevaContrasena) { this.Contrasena = NuevaContrasena; }
        


    }
}